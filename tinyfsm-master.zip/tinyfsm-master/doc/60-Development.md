Development
===========

Source Code Repository
----------------------

The source code for TinyFSM is managed using Git:

    git clone https://dev.tty0.ch/tinyfsm.git

Mirror on GitHub:

    git clone https://github.com/digint/tinyfsm.git


How to Contribute
-----------------

Your contributions are welcome!

If you would like to contribute or have found bugs, visit the [TinyFSM
project page on GitHub] and use the [issues tracker] there, or contact
the author via email.

  [TinyFSM project page on GitHub]: http://github.com/digint/tinyfsm
  [issues tracker]: http://github.com/digint/tinyfsm/issues
